import React from "react";
// import rubicWidget from "rubic-widget";

const RubicModal = () => {
  return <div id="rubic-widget-root"></div>;
};

export default RubicModal;
